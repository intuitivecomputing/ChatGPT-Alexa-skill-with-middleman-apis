/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');
const AWS = require("aws-sdk");
const ddbAdapter = require('ask-sdk-dynamodb-persistence-adapter');

const axios = require('axios');
var followUp = "false";
var tryAgain = "false";
const timeOut = 6000;
const sayIt = 2000;
//const task = "medical"; 
//const task = "trip"; 
const task = "discuss";

const apiCall = {call primary middlemanAPI} ; TODO
var questionAsked = false;




//var index_ques = 20;
const index_max = 14;
var fillers = [];
var filler_questions = [];
const intro_hi = ["Hello! ", "Hi! ", "Hey! ", "Welcome! "]
const intro_agent =["I am an intelligent conversational assistant designed to present requested information. ", 
"I am an intelligent virtual agent programmed to provide you with the requested information to the best of my ability. ",
"I am an AI assistant intended to furnish relevant information on request. ",
"As an intelligent voice assistant my purpose is to provide requested information as accurately as possible. ",
"I am here to provide information. "];
const intro = ['How can I assist you today?', 'What do you wanna know?', 'What questions do you have?', 'What would you like to know?'  ];
const other = ['Any other questions for me?', 'What else can I help you with?', 'Anything else you\'d like to know?', 'Anything else?'];
const bye = ["Goodbye!", "Untill next time!", "Take care!", "Stay safe!", "Bye!", "Have a good one!"];
var meanwhile = [];
const acknowledge = ["Hmm... ", "Well... ", "Noted... ", "Thanks for sharing... ", " I see... ", "Alright... "];
const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
     handle(handlerInput) {
        const index = Math.floor(Math.random() * 3);
        const index_hi = Math.floor(Math.random() * 3);
        const index_agent = Math.floor(Math.random() * 4); 
        const index2 = Math.floor(Math.random() * 3);
        let speakOutput = "" ;
        const reprompting = intro[index2];
        tryAgain = "false";
        
        if (task ==="medical"){
            speakOutput = "Oh! seems like you are not feeling well! May be I can help figure out what's wrong?";
            meanwhile = ["In the meantime... ","I am looking it up, meanwhile... ","While I get that for you... ","As I get that for you... ","While I am fetching that... ", "While we wait... "];
            fillers = ["Let me check that!", "searching!", "looking it up!", "fetching that!", "I'll quickly look that up!", "let me check!", "I'm on it!", "Give me a sec!", "Hold tight, looking!"];
            filler_questions = ["What's been the highlight of your week so far?", "Do you enjoy going outside?", "Are you a morning person or a night owl?", "Did you do anything new today?", "What's your typical day like?", 
            "What is your favorite food?", "What's your favorite hobby or pastime?", "Do you enjoy outdoor activities like hiking, biking, or camping?" ,"Do you have any pets?", "Have you seen any good movies or TV shows lately?", 
            "Any specific plans for today?", "What's a good book that you have read?", "What's your favourite way to relax?", "Are you watching any shows recently?", "Have you eaten at a good restaurant recently?"];
        }
        else if (task === "trip" || task ==="lab"){
            speakOutput = intro_hi[index_hi] + intro_agent[index_agent]  + intro[index];
            meanwhile = ["In the meantime... ","I am looking it up, meanwhile... ","While I get that for you... ","As I get that for you... ","While I am fetching that... ", "While we wait... "];
            fillers = ["Let me check that!", "searching!", "looking it up!", "fetching that!", "I'll quickly look that up!", "let me check!", "I'm on it!", "Give me a sec!", "Hold tight, looking!"];
            filler_questions = ["How are you today?", "How's your day going?", "Have you tried any new activities recently?", "Do you follow any sports or sporting events?",  "Do you like to keep to yourself?", 
            "How has the world changed since you were growing up?", "What are your plans for the day?", "Any interesting plans for next weekend?", "Do you have a favorite dessert?", "Do you know how to cook?", 
            "What kind of music do you like?",  "Are there any skills you've been meaning to learn or improve?", "Are you a fan of any particular TV show or movie genre?", "How do you like to celebrate special occasions or milestones?", "Do you have any favorite travel destinations or dream places to visit?"];
        }
        else if (task ==="discuss"){
            speakOutput = intro_hi[index_hi] + "I am a voice assistant designed to engage in a discussion with you. What would you like to talk about?" ;
            meanwhile = ["In the meantime... ","Thinking, meanwhile... ","While I think it over... ","As I contemplate that... ","While I am thinking about that... ", "While I ponder over that... "];
            fillers = ["Let me think about that!", "Hmmm. thinking!", "Just a moment!", "Hold on! contemplating.", "I'm going to give this some thought.", "Let me ponder that for a bit!", "Hmm, thinking it through!", "Processing my thoughts!", "Need a moment"];
            filler_questions = ["Do you listen to recent news?", "What recent news surprised you?", "How do you stay informed about political issues and events?", "Where would you rather live, Texas or Maryland?", "Who do you think will win the next US election? Republicans or Democrats?",
            "What do you do?", "What is your field?", "What's your favorite subject in school or college?",  "What advice would you give to someone starting their first year of college?", "What do you do for fun?", 
            "Do you live in a big city?", "What's your favorite spot to study or work? ", "What's your go-to method for staying focused while working?","Do you use any online learning platforms?" , "What's your favorite memory from your time at school or college so far?" ]
          
        }
        
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(reprompting)
            .getResponse();
    }
};



const AskChatGPTIntentHandler = {
  canHandle(handlerInput) {
    return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
      && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AskChatGPTIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhatIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhoIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhereIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhenIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhyIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhichIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhoseIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'HowIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'DoIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'HaveIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'CouldIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AreIntent'
      || Alexa.getIntentName(handlerInput.requestEnvelope) === 'TellIntent');
  },
  async handle(handlerInput) {
    let startTime = Date.now();
    var question = 
            Alexa.getSlotValue(handlerInput.requestEnvelope, 'question');
    if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhatIntent'){
        question = "What " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'HowIntent'){
        question = "How " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhoIntent'){
        question = "Who " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhereIntent'){
        question = "Where " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhenIntent'){
        question = "When " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhichIntent'){
        question = "Which " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhoseIntent'){
        question = "Whose " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'WhyIntent'){
        question = "Why " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'DoIntent'){
        question = "Do " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'HaveIntent'){
        question = "Have " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'CouldIntent'){
        question = "Should " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AreIntent'){
        question = "Are " + question;
    }
    else if (Alexa.getIntentName(handlerInput.requestEnvelope) === 'TellIntent'){
        question = "Tell " + question;
    }
    
    const timeoutId = setTimeout(() => {
    
        let progressiveApiResponsePromise = axios.post('https://api.amazonalexa.com/v1/directives', request, {
          headers: {
            Authorization: `Bearer ${apiAccessToken}`,
            'Content-Type': 'application/json'
          }
        })
        .then(response => {
          console.log('Directive sent successfully!');
        })
        .catch(error => {
          console.error('Error sending directive:', error);
        });
    
   //flagProgressiveAPI = true;
    
   
    },sayIt);
    
    
    //////////
    
    let apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;

    let apiResponsePromise = axios.post(apiUrl, "\"" + question + "\"", {
      headers: {
        //Authorization: authToken,
        'Content-Type': 'application/json',
        accept: '*/*',
      },
    });
    

    //progressive call 
   
   // Get the API access token and request ID
    const apiAccessToken = handlerInput.requestEnvelope.context.System.apiAccessToken;
    const requestId = handlerInput.requestEnvelope.request.requestId;

   
    const index_filler = Math.floor(Math.random() * 8);
    const repromptText2 = fillers[index_filler];
    
   
   const directive = {
      type: 'VoicePlayer.Speak',
      speech: repromptText2, 
    };
    const request = {
      header: {
        requestId: requestId
      },
      directive: directive
    };
    /////////////////////////////////////
    
    var speakOutput = await apiResponsePromise;
    let currentTime = Date.now();
    while (speakOutput.data === "Still working on that" && currentTime-startTime < timeOut){
        //counter++;
        tryAgain = "true";
        const apiUrl =apiCall+followUp+'&tryAgain='+tryAgain;
        let apiResponsePromise = axios.post(apiUrl,  "\"trying again\"", {
          headers: {
            //Authorization: authToken,
            'Content-Type': 'application/json',
            accept: '*/*',
          },
    });
    speakOutput = await apiResponsePromise;
    currentTime = Date.now();

    }
    clearTimeout(timeoutId);
    if (followUp === "false"){
        followUp = "true";
    }
    var repromptText = "";
    if (speakOutput.data === "Still working on that"){
        tryAgain = "true";
        repromptText = "Should I continue?";
        const index_meanwhile = Math.floor(Math.random() * 6);
        const attributesManager = handlerInput.attributesManager;
        let attributes = await attributesManager.getPersistentAttributes() || {};
        var counter = attributes.hasOwnProperty('counter')? attributes.counter : 0;
        speakOutput.data = meanwhile[index_meanwhile] + filler_questions[counter];
        if (counter >= index_max)
        {
            counter = -1;
        }
        counter++;
        attributes = {"counter":counter};
        
        attributesManager.setPersistentAttributes(attributes);
        await attributesManager.savePersistentAttributes();
        
        questionAsked = true;
        

    }
    else{
        if (questionAsked)
        {
            const index4 = Math.floor(Math.random() * 5);
            speakOutput.data =  acknowledge[index4] + speakOutput.data;
            questionAsked = false;
        }
        tryAgain = "false";
        const index2 = Math.floor(Math.random() * 3);
        repromptText = other[index2];
    }
    
   
    

    return handlerInput.responseBuilder
      .speak(speakOutput.data) 
      .reprompt(repromptText)
      .getResponse();
      
  }
};

const TryAgainIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.ResumeIntent'
            || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.YesIntent');
    },
    async handle(handlerInput) {
        let startTime = Date.now();
        const index2 = Math.floor(Math.random() * 3);
        const index = Math.floor(Math.random() * 3);
        let repromptText = other[index2];
        let speakText = other[index];
        //let speakText = "What else can I help you with.";
        //let repromptText = "What else can I help you with";
        if (tryAgain === "true"){
            const timeoutId = setTimeout(() => {
              // Make the API call to mark the directive as complete
                 //working
                let progressiveApiResponsePromise = axios.post('https://api.amazonalexa.com/v1/directives', request, {
                  headers: {
                    Authorization: `Bearer ${apiAccessToken}`,
                    'Content-Type': 'application/json'
                  }
                })
                .then(response => {
                  console.log('Directive sent successfully!');
                })
                .catch(error => {
                  console.error('Error sending directive:', error);
                });
            
            
           
            },sayIt);
            //////////
            const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
            let apiResponsePromise2 = axios.post(apiUrl, "\"trying again\"", {
              headers: {
                'Content-Type': 'application/json',
                accept: '*/*',
              },
            });
            

            //progressive call 
           
           // Get the API access token and request ID
            const apiAccessToken = handlerInput.requestEnvelope.context.System.apiAccessToken;
            const requestId = handlerInput.requestEnvelope.request.requestId;
        
           
            const index_filler = Math.floor(Math.random() * 8);
            const repromptText2 = fillers[index_filler];
            
           
           const directive = {
              type: 'VoicePlayer.Speak',
              speech: repromptText2, 
            };
            const request = {
              header: {
                requestId: requestId
              },
              directive: directive
            };
            /////////////////////////////////////
            
            var speakOutput2 = await apiResponsePromise2;
            let currentTime = Date.now();
            while (speakOutput2.data === "Still working on that" && currentTime-startTime < timeOut){
                tryAgain = "true";
                //counter++;
                const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
                let apiResponsePromise2 = axios.post(apiUrl, "\"trying again\"", {
                  headers: {
                    //Authorization: authToken,
                    'Content-Type': 'application/json',
                    accept: '*/*',
                  },
            });
            speakOutput2 = await apiResponsePromise2;
            currentTime = Date.now();

            }
            clearTimeout(timeoutId);
            //var repromptText = "";
            if (speakOutput2.data === "Still working on that"){
                tryAgain = "true";
                repromptText = "Should I continue?";
                const index_meanwhile = Math.floor(Math.random() * 6);
                const attributesManager = handlerInput.attributesManager;
                let attributes = await attributesManager.getPersistentAttributes() || {};
                var counter = attributes.hasOwnProperty('counter')? attributes.counter : 0;
                speakText = meanwhile[index_meanwhile] + filler_questions[counter];
                if (counter >= index_max)
                {
                    counter = -1;
                }
                counter++;
                attributes = {"counter":counter};
                
                attributesManager.setPersistentAttributes(attributes);
                await attributesManager.savePersistentAttributes();
                questionAsked = true;
                
            }
            else{
                tryAgain = "false";
                const index3 = Math.floor(Math.random() * 3);
                repromptText = other[index3];
                if (questionAsked)
                {
                    const index4 = Math.floor(Math.random() * 5);
                    speakText = acknowledge[index4] + speakOutput2.data;
                    questionAsked = false;
                }
                else{
                    speakText = speakOutput2.data;
                }
                
            }
        
        }
        return handlerInput.responseBuilder
            .speak(speakText)
            .reprompt(repromptText)
            .getResponse();
    }
};

const NoIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.NoIntent'
            || Alexa.getIntentName(handlerInput.requestEnvelope) === 'TryAgainIntent');
    },
    async handle(handlerInput) {

        let startTime = Date.now();
        const index2 = Math.floor(Math.random() * 3);
        const index = Math.floor(Math.random() * 3);
        let repromptText = other[index2];
        let speakText = other[index];
        if (tryAgain === "true"){
            const timeoutId = setTimeout(() => {

              // Make the API call to mark the directive as complete
                 //working
                let progressiveApiResponsePromise = axios.post('https://api.amazonalexa.com/v1/directives', request, {
                  headers: {
                    Authorization: `Bearer ${apiAccessToken}`,
                    'Content-Type': 'application/json'
                  }
                })
                .then(response => {
                  console.log('Directive sent successfully!');
                })
                .catch(error => {
                  console.error('Error sending directive:', error);
                });
            

           
            },sayIt);
            //////////
            const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
            //let counter = 0;
            let apiResponsePromise2 = axios.post(apiUrl, "\"trying again\"", {
              headers: {
                'Content-Type': 'application/json',
                accept: '*/*',
              },
            });

            //progressive call 
           
           // Get the API access token and request ID
            const apiAccessToken = handlerInput.requestEnvelope.context.System.apiAccessToken;
            const requestId = handlerInput.requestEnvelope.request.requestId;
        
           
            const index_filler = Math.floor(Math.random() * 8);
            const repromptText2 = fillers[index_filler];
            
           
           const directive = {
              type: 'VoicePlayer.Speak',
              speech: repromptText2, 
            };
            const request = {
              header: {
                requestId: requestId
              },
              directive: directive
            };
            /////////////////////////////////////
            
            var speakOutput2 = await apiResponsePromise2;
            let currentTime = Date.now();
            while (speakOutput2.data === "Still working on that" && currentTime-startTime < timeOut){
                tryAgain = "true";
                //counter++;
                const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
                let apiResponsePromise2 = axios.post(apiUrl, "\"trying again\"", {
                  headers: {
                    //Authorization: authToken,
                    'Content-Type': 'application/json',
                    accept: '*/*',
                  },
            });
            speakOutput2 = await apiResponsePromise2;
            currentTime = Date.now();

            }
            clearTimeout(timeoutId);
            if (speakOutput2.data === "Still working on that"){
                tryAgain = "true";
                repromptText = "Should I continue?";
                const index_meanwhile = Math.floor(Math.random() * 6);
                const attributesManager = handlerInput.attributesManager;
                let attributes = await attributesManager.getPersistentAttributes() || {};
                var counter = attributes.hasOwnProperty('counter')? attributes.counter : 0;
                speakText = meanwhile[index_meanwhile] + filler_questions[counter];
                if (counter >= index_max)
                {
                    counter = -1;
                }
                counter++;
                attributes = {"counter":counter};
                attributesManager.setPersistentAttributes(attributes);
                await attributesManager.savePersistentAttributes();
                questionAsked = true;
                
            }
            else{
                tryAgain = "false";
                const index3 = Math.floor(Math.random() * 3);
                repromptText = other[index3];
                if (questionAsked)
                {
                    const index4 = Math.floor(Math.random() * 5);
                    speakText = acknowledge[index4] + speakOutput2.data;
                    questionAsked = false;
                }
                else{
                    speakText = speakOutput2.data;
                }
            }
            return handlerInput.responseBuilder
            .speak(speakText)
            .reprompt(repromptText)
            .getResponse();
        
        }
        else{
            const index_bye = Math.floor(Math.random() * 5);
            const speakOutput = "If that's all" + bye[index_bye];
            return handlerInput.responseBuilder
                .speak(speakOutput)
                .reprompt("")
                .getResponse();
        }
    }
};

const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Is there something else you would like to know? Try saying chatbot before your question if you are trying to ask the voice assistant something';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    async handle(handlerInput) {
        let startTime = Date.now();
        var speakText = 'Sorry, I don\'t know about that. Is there something else you would like to know? Try saying echo or chatbot before your question if you are trying to ask the voice assistant something.';
        
        const index3 = Math.floor(Math.random() * 3);
        var repromptText = other[index3];
        if (tryAgain === "true"){
            
            const timeoutId = setTimeout(() => {

              // Make the API call to mark the directive as complete
                 //working
                let progressiveApiResponsePromise = axios.post('https://api.amazonalexa.com/v1/directives', request, {
                  headers: {
                    Authorization: `Bearer ${apiAccessToken}`,
                    'Content-Type': 'application/json'
                  }
                })
                .then(response => {
                  console.log('Directive sent successfully!');
                })
                .catch(error => {
                  console.error('Error sending directive:', error);
                });
            

            
           
            },sayIt);
            //////////
            
            const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
            let apiResponsePromise3 = axios.post(apiUrl, "\"trying again\"", {
              headers: {
                'Content-Type': 'application/json',
                accept: '*/*',
              },
            });
            
            
            //////// working code
            //progressive call 
           
           // Get the API access token and request ID
            const apiAccessToken = handlerInput.requestEnvelope.context.System.apiAccessToken;
            const requestId = handlerInput.requestEnvelope.request.requestId;
        
           
            const index_filler = Math.floor(Math.random() * 8);
            const repromptText2 = fillers[index_filler];
            
           
           const directive = {
              type: 'VoicePlayer.Speak',
              speech: repromptText2, 
            };
            const request = {
              header: {
                requestId: requestId
              },
              directive: directive
            };
            /////////////////////////////////////
            
            var speakOutput3 = await apiResponsePromise3;
            let currentTime = Date.now();
            while (speakOutput3.data === "Still working on that" && currentTime-startTime < timeOut){
                tryAgain = "true";
                //counter++;
                const apiUrl = apiCall+followUp+'&tryAgain='+tryAgain;
                let apiResponsePromise3 = axios.post(apiUrl, "\"trying again\"", {
                  headers: {
                    //Authorization: authToken,
                    'Content-Type': 'application/json',
                    accept: '*/*',
                  },
            });
            speakOutput3 = await apiResponsePromise3;
            currentTime = Date.now();

            }
            clearTimeout(timeoutId);
            if (speakOutput3.data === "Still working on that"){
                tryAgain = "true";
                repromptText = "Should I continue?";
                const index_meanwhile = Math.floor(Math.random() * 6);
                const attributesManager = handlerInput.attributesManager;
                let attributes = await attributesManager.getPersistentAttributes() || {};
                var counter = attributes.hasOwnProperty('counter')? attributes.counter : 0;
                speakText = meanwhile[index_meanwhile] + filler_questions[counter];
                if (counter >= index_max)
                {
                    counter = -1;
                }
                counter++;
                attributes = {"counter":counter};
                attributesManager.setPersistentAttributes(attributes);
                await attributesManager.savePersistentAttributes();
                questionAsked = true;
            }
            else{
                tryAgain = "false";
                const index4 = Math.floor(Math.random() * 3);
                repromptText = other[index4];
                if (questionAsked)
                {
                    const index4 = Math.floor(Math.random() * 5);
                    speakText = acknowledge [index4]  + speakOutput3.data;
                    questionAsked = false;
                }
                else{
                    speakText = speakOutput3.data;
                }
            }
        }
        
        return handlerInput.responseBuilder
            .speak(speakText) //"fallback" + 
            .reprompt(repromptText)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        tryAgain = "false";
        followUp = "false";
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);
        //tryAgain = "false";
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        AskChatGPTIntentHandler,
        TryAgainIntentHandler,
        NoIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
        //NavigateHomeIntentHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .withPersistenceAdapter(
        new ddbAdapter.DynamoDbPersistenceAdapter({
            tableName: process.env.DYNAMODB_PERSISTENCE_TABLE_NAME,
            createTable: false,
            dynamoDBClient: new AWS.DynamoDB({apiVersion: 'latest', region: process.env.DYNAMODB_PERSISTENCE_REGION})
        })
    )
    .lambda();