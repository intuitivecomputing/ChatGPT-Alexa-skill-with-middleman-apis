﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Sheets.v4;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ChatGPTMiddlemanAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class WaitAPIController : ControllerBase
    {
        static readonly string[] Scopes = { SheetsService.Scope.Spreadsheets };
        static readonly string ApplicationName = "Current Legislators";
        static readonly string SpreadsheetId = [spreadsheetID]; // TODO
        static readonly string sheet = "ChatGPT-database";
        static SheetsService? service;
        static  DateTime startDate = DateTime.Now;
        static int querries = 0;

        
        public  void ClearSpreadSheet()
        {
            // set up google sheets
            GoogleCredential credential;
            //CLIENT_SECRETS FROM GOOGLE API SERVICE
            using (var stream = new FileStream("client_secrets.json", FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                    .CreateScoped(Scopes);
            }

            // Create Google Sheets API service.
            service = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
            // update entry with FALSE
            var range2 = $"{sheet}!A2:C2";
            var valueRange = new ValueRange();
            var date = DateTime.Now.ToString("MM / dd / yyyy HH: mm");
            var oblist = new List<object>() { "", "FALSE", "" };
            valueRange.Values = new List<IList<object>> { oblist };

            var updateRequest = service.Spreadsheets.Values.Update(valueRange, SpreadsheetId, range2);
            updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
            var appendReponse2 = updateRequest.Execute();



            
        }

        [HttpPost]
        public async Task<IActionResult> CallChatGPT([FromBody] string SearchText, bool followUP = true, bool tryAgain = false)
        {
            string responseText = "";
            if (!tryAgain)
            {
                var httpClient = new HttpClient();
                var url = "";
                TimeSpan elapsed = DateTime.Now - startDate;
                startDate = DateTime.Now;
                //querries++;
                ClearSpreadSheet();
                if (followUP || elapsed.Minutes <= 20)// && querries <=10))
                {
                    url = [APIcall to seconday middleman API]; //TODO
                }
                else
                {
                    url = [APIcall to seconday middleman API]; //TODO
                    //querries = 0;
                }
                var requestBody = "\"" + SearchText + "\"";
                var httpRequest = new HttpRequestMessage(HttpMethod.Post, url);
                httpRequest.Headers.Accept.Clear();
                httpRequest.Headers.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("*/*"));
                httpRequest.Content = new StringContent(requestBody, System.Text.Encoding.UTF8, "application/json");
                try
                {

                    httpClient.SendAsync(httpRequest);
                 
                }
                catch (HttpRequestException ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }

            }

            GoogleCredential credential;
            using (var stream = new FileStream("client_secrets.json", FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                    .CreateScoped(Scopes);
            }

            // Create Google Sheets API service.
            service = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });



            var range = $"{sheet}!A2:C2";
            SpreadsheetsResource.ValuesResource.GetRequest request =
                    service.Spreadsheets.Values.Get(SpreadsheetId, range);

            var response = request.Execute();
            IList<IList<object>> values = response.Values;
            if (values != null && values.Count > 0)
            {
                foreach (var row in values)
                {

                    var indicator = "" + (row[1]);
                    if (indicator == "FALSE" || indicator == "")
                    {
                        return Ok("Still working on that");
                    }
                    else if (indicator == "TRUE")
                    {
                        responseText = row[2] + "";

                        var range2 = $"{sheet}!A2:C2";
                        var valueRange = new ValueRange();
                        var date = DateTime.Now.ToString("MM / dd / yyyy HH: mm");
                        var oblist = new List<object>() { "", "FALSE", "" };
                        valueRange.Values = new List<IList<object>> { oblist };

                        var updateRequest = service.Spreadsheets.Values.Update(valueRange, SpreadsheetId, range2);
                        updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
                        var appendReponse2 = updateRequest.Execute();

                        return Ok(responseText);
                    }

                }
            }
            else
            {
                Console.WriteLine("No data found.");
            }





            return Ok(responseText);
        }
    }
}
