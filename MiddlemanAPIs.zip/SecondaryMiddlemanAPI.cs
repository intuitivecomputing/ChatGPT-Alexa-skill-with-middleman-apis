﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OpenAI_API.Completions;
using OpenAI_API;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using System;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Services;
using OpenAI_API.Models;

namespace ChatGPTWebAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ChatGptController : ControllerBase
    {
        public static string apiKey = [openai APIKey]; //TODO
        public static OpenAIAPI openai = new OpenAIAPI(apiKey);
        public static OpenAI_API.Chat.Conversation chat = openai.Chat.CreateConversation();
        public static bool startOfAPI = true;
        // for google sheets api
        static readonly string[] Scopes = { SheetsService.Scope.Spreadsheets };
        static readonly string ApplicationName = "Current Legislators";
        static readonly string SpreadsheetId = [SPREADHSEET ID]; //TODO
        static readonly string sheet = "ChatGPT-database";
        static SheetsService? service;

        [HttpPost]
        public async Task<IActionResult> GetOpenAIResponse([FromBody] string SearchText )
        {
            //your OpenAI API key
            string answer = string.Empty;
     
            chat = openai.Chat.CreateConversation();
            chat.AppendSystemMessage("SYSTEM PROMPT FOR EACH TASK"); //TODO
            chat.AppendUserInput(SearchText);
            answer = await chat.GetResponseFromChatbotAsync();
           
            // set up google sheets
            GoogleCredential credential;
            using (var stream = new FileStream("client_secrets.json", FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                    .CreateScoped(Scopes);
            }

            // Create Google Sheets API service.
            service = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
            // update entry with 

            // update entry with response text
            var range = $"{sheet}!A2:C2";
            var valueRange = new ValueRange();
            var date = DateTime.Now.ToString("MM / dd / yyyy HH: mm");
            var oblist = new List<object>() { {date } , "TRUE", { answer } };
            valueRange.Values = new List<IList<object>> { oblist };

            var updateRequest = service.Spreadsheets.Values.Update(valueRange, SpreadsheetId, range);
            updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
            var appendReponse2 = updateRequest.Execute();

            return Ok(answer);

           
        }
        [HttpPost]
        public async Task<IActionResult> GetFollowUp([FromBody] string FollowUP)
        {
          
            string answer = string.Empty;
          
            string lastMessage = string.Empty;
            if(chat.Messages.Count >  30) {
                lastMessage = chat.Messages.Last().Content;
                chat = openai.Chat.CreateConversation();
                chat.AppendSystemMessage("SYSTEM PROMPT FOR EACH TASK"); //TODO
                chat.AppendExampleChatbotOutput(lastMessage);
            }
            chat.AppendSystemMessage("SYSTEM PROMPT FOR EACH TASK"); //TODO
            chat.AppendUserInput(FollowUP); 
            answer = await chat.GetResponseFromChatbotAsync();
           
            GoogleCredential credential;
            using (var stream = new FileStream("client_secrets.json", FileMode.Open, FileAccess.Read))
            {
                credential = GoogleCredential.FromStream(stream)
                    .CreateScoped(Scopes);
            }

            // Create Google Sheets API service.
            service = new SheetsService(new BaseClientService.Initializer()
            {
                HttpClientInitializer = credential,
                ApplicationName = ApplicationName,
            });
            // update entry with 

            var range = $"{sheet}!A2:C2";
            var valueRange = new ValueRange();
            var date = DateTime.Now.ToString("MM / dd / yyyy HH: mm");
            var oblist = new List<object>() { { date }, "TRUE", { answer } };
            valueRange.Values = new List<IList<object>> { oblist };

            var updateRequest = service.Spreadsheets.Values.Update(valueRange, SpreadsheetId, range);
            updateRequest.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
            var appendReponse2 = updateRequest.Execute();

            return Ok(answer);

            
           
        }
    }

        
}
